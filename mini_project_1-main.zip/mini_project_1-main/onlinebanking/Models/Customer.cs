public class Customer
{
    public int Id { get; set; }
    public string CustomerName { get; set; }
 
    public int AccountNumber{ get; set; }
    public string AccountType { get; set; }
    public string AccessCode { get; set; }
    public int Balance { get; set; }
}
